import { Component,Input,Output,EventEmitter} from "@angular/core";

@Component({

    selector:'child-counter-component',
    // template:`<h2> Display Counter from Child </h2>
    //             <button (click)="increment()"> Increment </button>
    //             <button (click)= "decrement()"> Decrement </button>
    //           current count is {{count}}  
    //         `
    template : `<h2> Display Counter from Child </h2>
                    Current Count is  {{count}}            
    `
})

export class ChildCounterComponent{
    
    count:number = 0
    // @Input () count : number = 0

    // @Output()  counterchanged : EventEmitter<number> = new EventEmitter()

    getcounter()
    {
        return this.count
    }

    increment(){
        this.count++
        //this.counterchanged.emit(this.count)
    }

    decrement(){
        this.count--
        //this.counterchanged.emit(this.count)
    }
}

