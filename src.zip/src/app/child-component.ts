import { Component,Input,SimpleChange,SimpleChanges,OnChanges } from "@angular/core";

@Component({

    selector:'child-component',
    template:`<h2> Display Counter </h2>
              current count is {{count}}  
            `
})

/* simplechanges is indexed list of simplechange */

/* There are 3 ways of passing data from child to parent 
1. Listen to Child event
2. Use Local Variable to access child
3. Use @viewChild to get the reference to the child component
*/


// export class ChildComponent implements OnChanges{
    export class ChildComponent{
    //@Input() count:number = 0
    private _count=0

    @Input()
    set count(count:number){
        if(count < 10){
        this._count=count;
        //console.log(count)
        }
    }
   get count():number{
        return this._count
    }
    
    ngOnChanges(changes:SimpleChanges){
        for (let property in changes){
            if(property==='count'){
                //console.log(changes[property].previousValue)
                 console.log('Previous Value',changes[property].previousValue)
                console.log('Current Value',changes[property].currentValue)
                 console.log('First Change',changes[property].firstChange)
            }
        }
    }
}

