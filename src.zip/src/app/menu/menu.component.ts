import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  menulist:any[] = []
  menulist_b:any[] = [
    {"itemname": "Punjabi food", "price": 1200 },
      {"itemname": "Chinese food", "price": 800 },
      {"itemname": "Continental food", "price": 1250 },
      {"itemname": "Bengali food", "price": 850 },
      {"itemname": "Thai food", "price": 1000 }
 
  ]
  
  setpricestyle : object = {
    'font-size': '12px',
    'color' : 'blue',
    'background-color' : 'gray'
  }
  
  setmenutype :boolean = true
  selectedmenuitem:string = ""
  setmenuclass = ""
  
  setmenuitem(m:string){
    this.selectedmenuitem = m
    console.log(m)
  }

  constructor() {

   }

  setmenu(menutype:string){

    if (menutype == "A"){
      this.setmenutype = true
      this.setmenuclass = "alcarte"
    }
    else{
      this.setmenutype = false
      this.setmenuclass = "banquet"
    }
 
  }

  ngOnInit(): void {

    this.menulist = [
      {"itemname": "Veg Thali", "price": 200 },
      {"itemname": "Chicken Thali", "price": 300 },
      {"itemname": "Veg Biryani", "price": 250 },
      {"itemname": "Chicken Biryani", "price": 350 },
      {"itemname": "Mini Thali", "price": 100 }
    ]
    this.setmenuclass = "alcarte"
  }

}
