export class Users {
    id?:any;
    username?:string;
    userage?:number;
    isAdult?:boolean;
}